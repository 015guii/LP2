namespace Pinss
{
    public partial class Form1 : Form
    {

        double salarioliq, descinss, descirpf, salfam, salbruto, alinss, alirpf;
        int filhos;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void mskbxSbruto_Validated(object sender, EventArgs e)
        {

        }

        private void mskbxFilhos_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void txtFilhos_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtFilhos.Text, out filhos))
            {
                MessageBox.Show("O n�mero de filhos deve seer inteiro.");
                txtFilhos.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (salbruto < 800.47)
            {
                alinss = 7.65;
                txtAlinss.Text = "7,65%";
            }
            else if (salbruto < 1050)
            {
                alinss = 8.65;
                txtAlinss.Text = "8,65%";
            }
            else if (salbruto < 1400.77)
            {
                alinss = 9;
                txtAlinss.Text = "9%";
            }
            else if (salbruto < 2801.56)
            {
                alinss = 11;
                txtAlinss.Text = "11%";
            }
            else
                txtAlinss.Text = "Teto";


            if (salbruto < 1257.12)
            {
                alirpf = 0;
                txtAlirpf.Text = "Isento";
            }
            else if (salbruto < 2512.08)
            {
                alirpf = 15;
                txtAlirpf.Text = "15%";
            }
            else
            {
                alirpf = 27.5;
                txtAlirpf.Text = "27,5%";
            }


            if (salbruto < 435.52)
            {
                salfam = 22.33 * filhos;
                txtSalfam.Text = salfam.ToString();
            }
            else if (salbruto < 654.61)
            {
                salfam = 15.74 * filhos;
                txtSalfam.Text = salfam.ToString();
            }
            else
            {
                salfam = 0;
                txtSalfam.Text = "0";
            }


            if (salbruto > 2801.56)
            {
                descinss = 308.17;
            }
            else
            {
                descinss = salbruto * (alinss / 100);
            }
            txtDinss.Text = descinss.ToString();

            descirpf = salbruto * (alirpf / 100);
            txtDirpf.Text = descirpf.ToString();

            salarioliq = salbruto - descinss - descirpf + salfam;
            txtSliquido.Text = salarioliq.ToString();
        }
    }
}