﻿namespace Pinss
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNome = new Label();
            lblSbruto = new Label();
            lblFilhos = new Label();
            txtNome = new TextBox();
            mskbxSbruto = new MaskedTextBox();
            btnCalcular = new Button();
            lblAinss = new Label();
            lblAirpf = new Label();
            lblSalfamilia = new Label();
            lblDirpf = new Label();
            lblSliquido = new Label();
            lblDinss = new Label();
            txtSalfam = new TextBox();
            txtAlirpf = new TextBox();
            txtAlinss = new TextBox();
            txtSliquido = new TextBox();
            txtDirpf = new TextBox();
            txtDinss = new TextBox();
            txtFilhos = new TextBox();
            SuspendLayout();
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Location = new Point(25, 49);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(129, 20);
            lblNome.TabIndex = 0;
            lblNome.Text = "Nome funcionário";
            // 
            // lblSbruto
            // 
            lblSbruto.AutoSize = true;
            lblSbruto.Location = new Point(25, 112);
            lblSbruto.Name = "lblSbruto";
            lblSbruto.Size = new Size(95, 20);
            lblSbruto.TabIndex = 1;
            lblSbruto.Text = "Sálario bruto";
            // 
            // lblFilhos
            // 
            lblFilhos.AutoSize = true;
            lblFilhos.Location = new Point(25, 172);
            lblFilhos.Name = "lblFilhos";
            lblFilhos.Size = new Size(124, 20);
            lblFilhos.TabIndex = 2;
            lblFilhos.Text = "Número de filhos";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(193, 49);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(317, 27);
            txtNome.TabIndex = 3;
            // 
            // mskbxSbruto
            // 
            mskbxSbruto.Location = new Point(193, 105);
            mskbxSbruto.Mask = "99999.99";
            mskbxSbruto.Name = "mskbxSbruto";
            mskbxSbruto.Size = new Size(65, 27);
            mskbxSbruto.TabIndex = 4;
            mskbxSbruto.Validated += mskbxSbruto_Validated;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(302, 105);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(221, 87);
            btnCalcular.TabIndex = 9;
            btnCalcular.Text = "Efetuar cálculos";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // lblAinss
            // 
            lblAinss.AutoSize = true;
            lblAinss.Location = new Point(25, 277);
            lblAinss.Name = "lblAinss";
            lblAinss.Size = new Size(101, 20);
            lblAinss.TabIndex = 10;
            lblAinss.Text = "Alíquota INSS";
            // 
            // lblAirpf
            // 
            lblAirpf.AutoSize = true;
            lblAirpf.Location = new Point(25, 334);
            lblAirpf.Name = "lblAirpf";
            lblAirpf.Size = new Size(98, 20);
            lblAirpf.TabIndex = 11;
            lblAirpf.Text = "Alíquota IRPF";
            // 
            // lblSalfamilia
            // 
            lblSalfamilia.AutoSize = true;
            lblSalfamilia.Location = new Point(25, 386);
            lblSalfamilia.Name = "lblSalfamilia";
            lblSalfamilia.Size = new Size(105, 20);
            lblSalfamilia.TabIndex = 12;
            lblSalfamilia.Text = "Sálario família";
            // 
            // lblDirpf
            // 
            lblDirpf.AutoSize = true;
            lblDirpf.Location = new Point(285, 334);
            lblDirpf.Name = "lblDirpf";
            lblDirpf.Size = new Size(104, 20);
            lblDirpf.TabIndex = 13;
            lblDirpf.Text = "Desconto IRPF";
            // 
            // lblSliquido
            // 
            lblSliquido.AutoSize = true;
            lblSliquido.Location = new Point(285, 386);
            lblSliquido.Name = "lblSliquido";
            lblSliquido.Size = new Size(106, 20);
            lblSliquido.TabIndex = 14;
            lblSliquido.Text = "Sálario líquido";
            // 
            // lblDinss
            // 
            lblDinss.AutoSize = true;
            lblDinss.Location = new Point(285, 277);
            lblDinss.Name = "lblDinss";
            lblDinss.Size = new Size(107, 20);
            lblDinss.TabIndex = 15;
            lblDinss.Text = "Desconto INSS";
            // 
            // txtSalfam
            // 
            txtSalfam.Location = new Point(151, 379);
            txtSalfam.Name = "txtSalfam";
            txtSalfam.ReadOnly = true;
            txtSalfam.Size = new Size(107, 27);
            txtSalfam.TabIndex = 19;
            // 
            // txtAlirpf
            // 
            txtAlirpf.Location = new Point(151, 327);
            txtAlirpf.Name = "txtAlirpf";
            txtAlirpf.ReadOnly = true;
            txtAlirpf.Size = new Size(107, 27);
            txtAlirpf.TabIndex = 20;
            // 
            // txtAlinss
            // 
            txtAlinss.Location = new Point(151, 274);
            txtAlinss.Name = "txtAlinss";
            txtAlinss.ReadOnly = true;
            txtAlinss.Size = new Size(107, 27);
            txtAlinss.TabIndex = 21;
            // 
            // txtSliquido
            // 
            txtSliquido.Location = new Point(416, 383);
            txtSliquido.Name = "txtSliquido";
            txtSliquido.ReadOnly = true;
            txtSliquido.Size = new Size(107, 27);
            txtSliquido.TabIndex = 22;
            // 
            // txtDirpf
            // 
            txtDirpf.Location = new Point(416, 327);
            txtDirpf.Name = "txtDirpf";
            txtDirpf.ReadOnly = true;
            txtDirpf.Size = new Size(107, 27);
            txtDirpf.TabIndex = 23;
            // 
            // txtDinss
            // 
            txtDinss.Location = new Point(416, 277);
            txtDinss.Name = "txtDinss";
            txtDinss.ReadOnly = true;
            txtDinss.Size = new Size(107, 27);
            txtDinss.TabIndex = 24;
            // 
            // txtFilhos
            // 
            txtFilhos.Location = new Point(193, 165);
            txtFilhos.Name = "txtFilhos";
            txtFilhos.Size = new Size(65, 27);
            txtFilhos.TabIndex = 25;
            txtFilhos.Validated += txtFilhos_Validated;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(557, 450);
            Controls.Add(txtFilhos);
            Controls.Add(txtDinss);
            Controls.Add(txtDirpf);
            Controls.Add(txtSliquido);
            Controls.Add(txtAlinss);
            Controls.Add(txtAlirpf);
            Controls.Add(txtSalfam);
            Controls.Add(lblDinss);
            Controls.Add(lblSliquido);
            Controls.Add(lblDirpf);
            Controls.Add(lblSalfamilia);
            Controls.Add(lblAirpf);
            Controls.Add(lblAinss);
            Controls.Add(btnCalcular);
            Controls.Add(mskbxSbruto);
            Controls.Add(txtNome);
            Controls.Add(lblFilhos);
            Controls.Add(lblSbruto);
            Controls.Add(lblNome);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNome;
        private Label lblSbruto;
        private Label lblFilhos;
        private TextBox txtNome;
        private MaskedTextBox mskbxSbruto;
        private Button btnCalcular;
        private Label lblAinss;
        private Label lblAirpf;
        private Label lblSalfamilia;
        private Label lblDirpf;
        private Label lblSliquido;
        private Label lblDinss;
        private TextBox txtSalfam;
        private TextBox txtAlirpf;
        private TextBox txtAlinss;
        private TextBox txtSliquido;
        private TextBox txtDirpf;
        private TextBox txtDinss;
        private TextBox txtFilhos;
    }
}