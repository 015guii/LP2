﻿namespace Pmetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            lblPalavra1 = new Label();
            lblPalavra2 = new Label();
            btnIguais = new Button();
            btnInserira = new Button();
            btnInserirp = new Button();
            SuspendLayout();
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(180, 54);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(170, 27);
            txtPalavra1.TabIndex = 0;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(180, 137);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(170, 27);
            txtPalavra2.TabIndex = 1;
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(44, 54);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(68, 20);
            lblPalavra1.TabIndex = 2;
            lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Location = new Point(44, 144);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(68, 20);
            lblPalavra2.TabIndex = 3;
            lblPalavra2.Text = "Palavra 2";
            // 
            // btnIguais
            // 
            btnIguais.Location = new Point(44, 216);
            btnIguais.Name = "btnIguais";
            btnIguais.Size = new Size(89, 68);
            btnIguais.TabIndex = 5;
            btnIguais.Text = "Compara iguais";
            btnIguais.UseVisualStyleBackColor = true;
            btnIguais.Click += btnIguais_Click;
            // 
            // btnInserira
            // 
            btnInserira.Location = new Point(261, 216);
            btnInserira.Name = "btnInserira";
            btnInserira.Size = new Size(89, 68);
            btnInserira.TabIndex = 7;
            btnInserira.Text = "Inserir **";
            btnInserira.UseVisualStyleBackColor = true;
            btnInserira.Click += btnInserira_Click;
            // 
            // btnInserirp
            // 
            btnInserirp.Location = new Point(151, 216);
            btnInserirp.Name = "btnInserirp";
            btnInserirp.Size = new Size(89, 68);
            btnInserirp.TabIndex = 8;
            btnInserirp.Text = "Inserir palavra";
            btnInserirp.UseVisualStyleBackColor = true;
            btnInserirp.Click += btnCopia1_Click;
            // 
            // frmExercicio2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnInserirp);
            Controls.Add(btnInserira);
            Controls.Add(btnIguais);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Name = "frmExercicio2";
            Text = "frmExercicio2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
        private Label lblPalavra1;
        private Label lblPalavra2;
        private Button btnIguais;
        private Button btnInserira;
        private Button btnInserirp;
    }
}