﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int num1, num2;

            if (int.TryParse(txtNum1.Text, out num1) && int.TryParse(txtNum2.Text, out num2) && num1 > 0 && num2 > 0)
            {
               
                    if (num1 < num2)
                    {
                        Random obj = new Random();
                        int resultado = obj.Next(num1, num2);
                        MessageBox.Show($"O número sorteado é {resultado}");
                    }
                    else
                    {
                        MessageBox.Show("O primeiro número deve ser menor que o segundo");
                    }
            }
            else
            {
                MessageBox.Show("Os valores devem ser números inteiros maiores que zero");
            }
        }
    }
}
