﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnRemover1_Click(object sender, EventArgs e)
        {
            string str2 = txtPalavra2.Text;
            string str1 = txtPalavra1.Text;
            int i;
            while ((i = str2.IndexOf(str1, StringComparison.OrdinalIgnoreCase)) != -1)
            {
                str2 = str2.Substring(0, i) + str2.Substring(i + str1.Length);
            }
            txtResultado.Text = str2;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string str2 = txtPalavra2.Text;
            string str1 = txtPalavra1.Text;
            txtResultado.Text = str2.Replace(str1, string.Empty, StringComparison.OrdinalIgnoreCase);
        }

        private void btnInverter_Click(object sender, EventArgs e)
        {
            //Não consegui fazer usando o método array
        }
    }
}
