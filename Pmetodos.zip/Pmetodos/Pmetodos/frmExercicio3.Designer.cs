﻿namespace Pmetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtPalavra1 = new TextBox();
            txtPalavra2 = new TextBox();
            txtResultado = new TextBox();
            btnRemover1 = new Button();
            btnInverter = new Button();
            btnRemover2 = new Button();
            lblPalavra1 = new Label();
            lblPalavra2 = new Label();
            lblResultado = new Label();
            SuspendLayout();
            // 
            // txtPalavra1
            // 
            txtPalavra1.Location = new Point(154, 35);
            txtPalavra1.Name = "txtPalavra1";
            txtPalavra1.Size = new Size(125, 27);
            txtPalavra1.TabIndex = 0;
            // 
            // txtPalavra2
            // 
            txtPalavra2.Location = new Point(154, 97);
            txtPalavra2.Name = "txtPalavra2";
            txtPalavra2.Size = new Size(125, 27);
            txtPalavra2.TabIndex = 1;
            // 
            // txtResultado
            // 
            txtResultado.Location = new Point(154, 155);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(125, 27);
            txtResultado.TabIndex = 2;
            // 
            // btnRemover1
            // 
            btnRemover1.Location = new Point(28, 235);
            btnRemover1.Name = "btnRemover1";
            btnRemover1.Size = new Size(85, 78);
            btnRemover1.TabIndex = 3;
            btnRemover1.Text = "Remover 1 ";
            btnRemover1.UseVisualStyleBackColor = true;
            btnRemover1.Click += btnRemover1_Click;
            // 
            // btnInverter
            // 
            btnInverter.Location = new Point(231, 235);
            btnInverter.Name = "btnInverter";
            btnInverter.Size = new Size(87, 78);
            btnInverter.TabIndex = 4;
            btnInverter.Text = "Inverter palavra";
            btnInverter.UseVisualStyleBackColor = true;
            btnInverter.Click += btnInverter_Click;
            // 
            // btnRemover2
            // 
            btnRemover2.Location = new Point(132, 235);
            btnRemover2.Name = "btnRemover2";
            btnRemover2.Size = new Size(83, 78);
            btnRemover2.TabIndex = 5;
            btnRemover2.Text = "Remover 2";
            btnRemover2.UseVisualStyleBackColor = true;
            btnRemover2.Click += button3_Click;
            // 
            // lblPalavra1
            // 
            lblPalavra1.AutoSize = true;
            lblPalavra1.Location = new Point(37, 42);
            lblPalavra1.Name = "lblPalavra1";
            lblPalavra1.Size = new Size(68, 20);
            lblPalavra1.TabIndex = 6;
            lblPalavra1.Text = "Palavra 1";
            // 
            // lblPalavra2
            // 
            lblPalavra2.AutoSize = true;
            lblPalavra2.Location = new Point(37, 104);
            lblPalavra2.Name = "lblPalavra2";
            lblPalavra2.Size = new Size(68, 20);
            lblPalavra2.TabIndex = 7;
            lblPalavra2.Text = "Palavra 2";
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(37, 162);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(75, 20);
            lblResultado.TabIndex = 8;
            lblResultado.Text = "Resultado";
            // 
            // frmExercicio3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblResultado);
            Controls.Add(lblPalavra2);
            Controls.Add(lblPalavra1);
            Controls.Add(btnRemover2);
            Controls.Add(btnInverter);
            Controls.Add(btnRemover1);
            Controls.Add(txtResultado);
            Controls.Add(txtPalavra2);
            Controls.Add(txtPalavra1);
            Name = "frmExercicio3";
            Text = "frmExercicio3";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtPalavra1;
        private TextBox txtPalavra2;
        private TextBox txtResultado;
        private Button btnRemover1;
        private Button btnInverter;
        private Button btnRemover2;
        private Label lblPalavra1;
        private Label lblPalavra2;
        private Label lblResultado;
    }
}