﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int letras = 0;

            foreach(var c in rchtxtFrase.Text)
            {
                if(char.IsLetter(c))
                    letras++;
            }
            MessageBox.Show($"A frase tem {letras} letras");
        }

        private void btnNum_Click(object sender, EventArgs e)
        {
            int numeros = 0;
            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsNumber(rchtxtFrase.Text[i]) == true)
                    numeros++;
            }

            MessageBox.Show($"A frase tem {numeros} números");
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int i = 0;
            int posbranco = 0;
            
            while(i < rchtxtFrase.Text.Length && posbranco == 0)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                    posbranco = i + 1;

                    i++;
            }

            MessageBox.Show($"A posição do 1º caracter em branco é {posbranco}");
        }
    }
}
