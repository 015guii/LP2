﻿namespace Pmetodos
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtNum1 = new TextBox();
            txtNum2 = new TextBox();
            btnSortear = new Button();
            lblNum1 = new Label();
            lblNum2 = new Label();
            SuspendLayout();
            // 
            // txtNum1
            // 
            txtNum1.Location = new Point(164, 65);
            txtNum1.Name = "txtNum1";
            txtNum1.Size = new Size(125, 27);
            txtNum1.TabIndex = 0;
            // 
            // txtNum2
            // 
            txtNum2.Location = new Point(164, 114);
            txtNum2.Name = "txtNum2";
            txtNum2.Size = new Size(125, 27);
            txtNum2.TabIndex = 1;
            // 
            // btnSortear
            // 
            btnSortear.Location = new Point(117, 191);
            btnSortear.Name = "btnSortear";
            btnSortear.Size = new Size(110, 40);
            btnSortear.TabIndex = 2;
            btnSortear.Text = "Sortear";
            btnSortear.UseVisualStyleBackColor = true;
            btnSortear.Click += btnSortear_Click;
            // 
            // lblNum1
            // 
            lblNum1.AutoSize = true;
            lblNum1.Location = new Point(55, 72);
            lblNum1.Name = "lblNum1";
            lblNum1.Size = new Size(75, 20);
            lblNum1.TabIndex = 3;
            lblNum1.Text = "Número 1";
            // 
            // lblNum2
            // 
            lblNum2.AutoSize = true;
            lblNum2.Location = new Point(55, 121);
            lblNum2.Name = "lblNum2";
            lblNum2.Size = new Size(75, 20);
            lblNum2.TabIndex = 4;
            lblNum2.Text = "Número 2";
            // 
            // frmExercicio5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 445);
            Controls.Add(lblNum2);
            Controls.Add(lblNum1);
            Controls.Add(btnSortear);
            Controls.Add(txtNum2);
            Controls.Add(txtNum1);
            Name = "frmExercicio5";
            Text = "frmExercicio5";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNum1;
        private TextBox txtNum2;
        private Button btnSortear;
        private Label lblNum1;
        private Label lblNum2;
    }
}