﻿namespace Pmetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rchtxtFrase = new RichTextBox();
            btnNum = new Button();
            btnBranco = new Button();
            btnLetras = new Button();
            lblFrase = new Label();
            SuspendLayout();
            // 
            // rchtxtFrase
            // 
            rchtxtFrase.Location = new Point(130, 52);
            rchtxtFrase.Name = "rchtxtFrase";
            rchtxtFrase.Size = new Size(658, 200);
            rchtxtFrase.TabIndex = 0;
            rchtxtFrase.Text = "";
            // 
            // btnNum
            // 
            btnNum.Location = new Point(198, 279);
            btnNum.Name = "btnNum";
            btnNum.Size = new Size(129, 81);
            btnNum.TabIndex = 1;
            btnNum.Text = "Total números";
            btnNum.UseVisualStyleBackColor = true;
            btnNum.Click += btnNum_Click;
            // 
            // btnBranco
            // 
            btnBranco.Location = new Point(393, 279);
            btnBranco.Name = "btnBranco";
            btnBranco.Size = new Size(124, 81);
            btnBranco.TabIndex = 2;
            btnBranco.Text = "Posição 1º caracter em branco";
            btnBranco.UseVisualStyleBackColor = true;
            btnBranco.Click += btnBranco_Click;
            // 
            // btnLetras
            // 
            btnLetras.Location = new Point(595, 279);
            btnLetras.Name = "btnLetras";
            btnLetras.Size = new Size(112, 81);
            btnLetras.TabIndex = 3;
            btnLetras.Text = "Total de letras";
            btnLetras.UseVisualStyleBackColor = true;
            btnLetras.Click += button3_Click;
            // 
            // lblFrase
            // 
            lblFrase.AutoSize = true;
            lblFrase.Location = new Point(41, 136);
            lblFrase.Name = "lblFrase";
            lblFrase.Size = new Size(43, 20);
            lblFrase.TabIndex = 4;
            lblFrase.Text = "Frase";
            lblFrase.Click += label1_Click;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 372);
            Controls.Add(lblFrase);
            Controls.Add(btnLetras);
            Controls.Add(btnBranco);
            Controls.Add(btnNum);
            Controls.Add(rchtxtFrase);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox rchtxtFrase;
        private Button btnNum;
        private Button btnBranco;
        private Button btnLetras;
        private Label lblFrase;
    }
}